/**
 * VideoPostPlayer.tsx — Inline video for the social feed.
 *
 * - No download / PiP / playback rate controls
 * - Autoplay UNMUTED when ≥ 40% visible (browser may still force muted on first load)
 * - Muted fallback if browser blocks unmuted autoplay
 * - Tap to toggle play/pause
 * - Loop playback
 * - Zero browser chrome
 */
import { useRef, useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Play, Volume2, VolumeX } from "lucide-react";
import { MusicDisc } from "./MusicDisc";
import type { PostSound } from "@/lib/postsClient";

interface Props {
  url: string;
  posterUrl?: string;
  aspectRatio?: string;
  autoplayThreshold?: number;
  sound?: PostSound | null;
}

export function VideoPostPlayer({
  url,
  posterUrl,
  aspectRatio = "4/5",
  autoplayThreshold = 0.4,
  sound,
}: Props) {
  const videoRef     = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [playing, setPlaying] = useState(false);
  const [started, setStarted] = useState(false);
  const [errored, setErrored] = useState(false);
  const [muted, setMuted] = useState(true);
  /* Preserve the uploaded video's real aspect ratio (no forced crop) —
   * `aspectRatio` is a best-guess placeholder until metadata loads, then
   * we swap to the video's true width/height so portrait stays portrait,
   * landscape stays landscape, square stays square — matching X. */
  const [ratio, setRatio] = useState(aspectRatio);
  const handleLoadedMetadata = useCallback((e: React.SyntheticEvent<HTMLVideoElement>) => {
    const v = e.currentTarget;
    if (v.videoWidth && v.videoHeight) setRatio(`${v.videoWidth}/${v.videoHeight}`);
  }, []);

  /* ── IntersectionObserver — autoplay unmuted, muted fallback ─────────── */
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    const observer = new IntersectionObserver(
      (entries) => {
        const entry = entries[0];
        const video = videoRef.current;
        if (!video || errored) return;

        if (entry.isIntersecting && entry.intersectionRatio >= autoplayThreshold) {
          video.muted = true;
          setMuted(true);
          video.play()
            .then(() => { setPlaying(true); setStarted(true); })
            .catch(() => {
              video.muted = true;
              video.play()
                .then(() => { setPlaying(true); setStarted(true); })
                .catch(() => {});
            });
        } else {
          video.pause();
          setPlaying(false);
        }
      },
      { threshold: autoplayThreshold },
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, [autoplayThreshold, errored]);

  const togglePlay = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    if (playing) {
      video.pause();
      setPlaying(false);
    } else {
      video.muted = muted;
      video.play()
        .then(() => setPlaying(true))
        .catch(() => {
          video.muted = true;
          video.play().then(() => setPlaying(true)).catch(() => {});
        });
      setStarted(true);
    }
  }, [playing]);

  const toggleMute = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    const video = videoRef.current;
    if (!video) return;
    const next = !video.muted;
    video.muted = next;
    setMuted(next);
    if (!next && video.paused) {
      video.play().catch(() => { video.muted = true; setMuted(true); });
    }
  }, []);

  if (errored && posterUrl) {
    return (
      <div className="relative w-full overflow-hidden bg-black/90" style={{ aspectRatio }}>
        <img src={posterUrl} alt="" className="h-full w-full object-cover" />
        <div className="absolute inset-0 flex items-center justify-center bg-black/40">
          <span className="text-xs text-white/60">Video unavailable</span>
        </div>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="relative w-full overflow-hidden bg-black rounded-[14px]"
      style={{ aspectRatio: ratio, maxHeight: "700px" }}
      onClick={togglePlay}
    >
      <video
        ref={videoRef}
        src={url}
        poster={posterUrl}
        loop
        playsInline
        preload="metadata"
        disablePictureInPicture
        controlsList="nodownload noplaybackrate nofullscreen"
        onContextMenu={(e) => e.preventDefault()}
        onError={() => setErrored(true)}
        onPlay={() => setPlaying(true)}
        onPause={() => setPlaying(false)}
        onLoadedMetadata={handleLoadedMetadata}
        className="h-full w-full object-contain"
        style={{ display: "block" }}
      />

      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-black/55 to-transparent" />

      <button
        type="button"
        onClick={toggleMute}
        aria-label={muted ? "Unmute video" : "Mute video"}
        className="absolute right-3 bottom-3 z-20 grid h-9 w-9 place-items-center rounded-full bg-black/55 text-white backdrop-blur-sm"
      >
        {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
      </button>

      {/* Play overlay — shown when paused */}
      <AnimatePresence>
        {!playing && (
          <motion.div
            key="play"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{ duration: 0.15 }}
            className="pointer-events-none absolute inset-0 flex items-center justify-center"
          >
            <div className="grid h-14 w-14 place-items-center rounded-full bg-black/50 backdrop-blur-sm">
              <Play className="h-6 w-6 fill-white text-white ml-0.5" />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Music disc — only when the post has a sound attached */}
      {sound && (
        <MusicDisc
          sound={sound as any}
          playing={playing}
        />
      )}
    </div>
  );
}
