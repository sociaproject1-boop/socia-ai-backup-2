import { lazy, Suspense, useEffect, type ComponentType } from "react";
import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AppShell } from "@/components/shell/AppShell";
import { useAppStore } from "@/lib/store";
import { AuthProvider, useAuth } from "@/lib/authContext";
import { PreferencesProvider } from "@/lib/PreferencesContext";
import UpdateGate from "@/components/UpdateGate";
import { ComingSoonGuard } from "@/components/ComingSoonGuard";
import { Toaster } from "@/components/ui/toaster";
import {
  adminFetchSession,
  hasAdminToken,
  useAdminStore,
} from "@/lib/adminAuth";
import { GlobalLoaderProvider } from "@/components/loader/GlobalLoaderProvider";
import { GlobalAIGenerationOverlay } from "@/components/loader/GlobalAIGenerationOverlay";
import { CinematicLoadingOverlay } from "@/components/loader/CinematicLoadingOverlay";
import { SplashScreen } from "@/components/splash/SplashScreen";
import { PulseViewerHost } from "@/components/pulse/PulseViewer";
import { LoginRequiredModal } from "@/components/auth/LoginRequiredModal";
import { useLoginGateStore } from "@/lib/useLoginGate";
import { RouteErrorBoundary } from "@/components/RouteErrorBoundary";

// ── Critical path (eager) ────────────────────────────────────────────────────
// Auth is the unauthenticated landing page — must be available without delay.
// Home is the authenticated landing page — loaded while auth resolves.
import Auth from "@/pages/Auth";
import Home from "@/pages/Home";

// ── All other pages: lazy-loaded ─────────────────────────────────────────────
// The browser only downloads a page's chunk on first navigation to it.
// In production this cuts the initial JS parse by ~60-70%.
function lazyWithRetry<T extends ComponentType<any>>(loader: () => Promise<{ default: T }>, key: string) {
  return lazy(async () => {
    try {
      return await loader();
    } catch (error) {
      // One automatic recovery for stale Vite chunks after a deployment.
      const retryKey = `socia_chunk_retry:${key}`;
      try {
        if (!sessionStorage.getItem(retryKey)) {
          sessionStorage.setItem(retryKey, "1");
          window.location.reload();
          return new Promise<never>(() => {});
        }
        sessionStorage.removeItem(retryKey);
      } catch { /* storage unavailable */ }
      throw error;
    }
  });
}

const loadAiAcademyMarketplace = () => import("@/pages/AiAcademyMarketplace");
const AiAcademyMarketplace = lazyWithRetry(loadAiAcademyMarketplace, "academy");
const CreatePromptImage = lazyWithRetry(() => import("@/pages/CreatePromptImage"), "CreatePromptImage");
const CreatePromptVideo = lazyWithRetry(() => import("@/pages/CreatePromptVideo"), "CreatePromptVideo");
const CreateImageVideo = lazyWithRetry(() => import("@/pages/CreateImageVideo"), "CreateImageVideo");
const CreateMultiFrame = lazyWithRetry(() => import("@/pages/CreateMultiFrame"), "CreateMultiFrame");
const Studio = lazyWithRetry(() => import("@/pages/Studio"), "Studio");
const StudioPreset = lazyWithRetry(() => import("@/pages/StudioPreset"), "StudioPreset");
const MyCreations = lazyWithRetry(() => import("@/pages/MyCreations"), "MyCreations");
const SociaGpt = lazyWithRetry(() => import("@/pages/SociaGpt"), "SociaGpt");
const SociaGptBilling = lazyWithRetry(() => import("@/pages/SociaGptBilling"), "SociaGptBilling");
const RefundThread = lazyWithRetry(() => import("@/pages/RefundThread"), "RefundThread");
const Messages = lazyWithRetry(() => import("@/pages/Messages"), "Messages");
const ChatThread = lazyWithRetry(() => import("@/pages/ChatThread"), "ChatThread");
const Profile = lazyWithRetry(() => import("@/pages/Profile"), "Profile");
const UserProfile = lazyWithRetry(() => import("@/pages/UserProfile"), "UserProfile");
const Settings = lazyWithRetry(() => import("@/pages/Settings"), "Settings");
const ResetPassword = lazyWithRetry(() => import("@/pages/ResetPassword"), "ResetPassword");
const PostDetail = lazyWithRetry(() => import("@/pages/PostDetail"), "PostDetail");
const LegalPage = lazyWithRetry(() => import("@/pages/LegalPage"), "LegalPage");
const FollowList = lazyWithRetry(() => import("@/pages/Followers"), "Followers");
const Subscribe = lazyWithRetry(() => import("@/pages/Subscribe"), "Subscribe");
const Billing = lazyWithRetry(() => import("@/pages/Billing"), "Billing");
const BillingUpgrade = lazyWithRetry(() => import("@/pages/BillingUpgrade"), "BillingUpgrade");
const BillingSuccess = lazyWithRetry(() => import("@/pages/BillingSuccess"), "BillingSuccess");
const BillingCancelled = lazyWithRetry(() => import("@/pages/BillingCancelled"), "BillingCancelled");
const SupportSuccess = lazyWithRetry(() => import("@/pages/SupportSuccess"), "SupportSuccess");
const SupportCancelled = lazyWithRetry(() => import("@/pages/SupportCancelled"), "SupportCancelled");
const AuthCallback = lazyWithRetry(() => import("@/pages/AuthCallback"), "AuthCallback");
const SysAdminLogin = lazyWithRetry(() => import("@/pages/SysAdminLogin"), "SysAdminLogin");
const SysAdmin = lazyWithRetry(() => import("@/pages/SysAdmin"), "SysAdmin");
const AdminLogin = lazyWithRetry(() => import("@/pages/AdminLogin"), "AdminLogin");
const AdminDashboard = lazyWithRetry(() => import("@/pages/AdminDashboard"), "AdminDashboard");
const UserByUsername = lazyWithRetry(() => import("@/pages/UserByUsername"), "UserByUsername");
const NotFound = lazyWithRetry(() => import("@/pages/not-found"), "not-found");
const CreatorMonetization = lazyWithRetry(() => import("@/pages/CreatorMonetization"), "CreatorMonetization");
const AffiliateProgram = lazyWithRetry(() => import("@/pages/AffiliateProgram"), "AffiliateProgram");
const SellerCenter = lazyWithRetry(() => import("@/pages/SellerCenter"), "SellerCenter");
const CreatorStars = lazyWithRetry(() => import("@/pages/CreatorStars"), "CreatorStars");
const SystemStatusCenter = lazyWithRetry(() => import("@/pages/SystemStatusCenter"), "SystemStatusCenter");
const AICommandCenter = lazyWithRetry(() => import("@/pages/AICommandCenter"), "AICommandCenter");
const UploadPage = lazyWithRetry(() => import("@/pages/Upload"), "Upload");
const PublicStatus = lazyWithRetry(() => import("@/pages/PublicStatus"), "PublicStatus");
const SupportHub = lazyWithRetry(() => import("@/pages/SupportHub"), "SupportHub");
const SocialNotifications = lazyWithRetry(() => import("@/pages/SocialNotifications"), "SocialNotifications");
const SearchPage = lazyWithRetry(() => import("@/pages/Search"), "Search");
const CreatorDashboard = lazyWithRetry(() => import("@/pages/CreatorDashboard"), "CreatorDashboard");
const LiveStream = lazyWithRetry(() => import("@/pages/LiveStream"), "LiveStream");
const GoLive = lazyWithRetry(() => import("@/pages/GoLive"), "GoLive");
const FriendsPage = lazyWithRetry(() => import("@/pages/Friends"), "Friends");
const PulseAdminPage = lazyWithRetry(() => import("@/pages/PulseAdmin"), "PulseAdmin");
const SoundPage = lazyWithRetry(() => import("@/pages/SoundPage"), "SoundPage");
const CameraCreator = lazyWithRetry(() => import("@/pages/CameraCreator"), "CameraCreator");
const ExplorePage = lazyWithRetry(() => import("@/pages/Explore"), "Explore");
const HashtagFeedPage = lazyWithRetry(() => import("@/pages/HashtagFeed"), "HashtagFeed");
const TrendingPage = lazyWithRetry(() => import("@/pages/Trending"), "Trending");
const GroupThread = lazyWithRetry(() => import("@/pages/GroupThread"), "GroupThread");

// Stable wrapper components defined outside Router to avoid remounts on re-render.
// They reference lazy components which are resolved by the nearest Suspense boundary.
const TermsPage       = () => <LegalPage kind="terms" />;
const PrivacyPage     = () => <LegalPage kind="privacy" />;
const LicensesPage    = () => <LegalPage kind="licenses" />;
const DeveloperPage   = () => <LegalPage kind="developer" />;
const FollowersPage   = () => <FollowList mode="followers" />;
const FollowingPage   = () => <FollowList mode="following" />;
// Stable wrapper so wouter's injected `params` prop doesn't conflict with
// SysAdmin's typed props.
const SysAdminPage    = () => <SysAdmin />;

// Shown inside AppShell (nav stays visible) while a lazy chunk is downloading.
// Uses the same shimmer utility class used elsewhere in the app.
function PageSkeleton() {
  return (
    <div className="h-full overflow-y-auto app-bg px-4 pt-5 space-y-3">
      <div className="h-6 w-2/3 rounded-2xl shimmer" />
      <div className="h-44 w-full rounded-3xl shimmer" />
      <div className="h-4 w-full rounded-xl shimmer" />
      <div className="h-4 w-5/6 rounded-xl shimmer" />
      <div className="h-36 w-full rounded-3xl shimmer" />
      <div className="h-36 w-full rounded-3xl shimmer" />
    </div>
  );
}

const queryClient = new QueryClient();

function AuthGuard({ children }: { children: React.ReactNode }) {
  const isAuthenticated = useAppStore((s) => s.isAuthenticated);
  const { loading } = useAuth();
  const [location, navigate] = useLocation();

  const isPublic = location === "/auth"
    || location === "/auth/callback"
    || location === "/forgot-password"
    || location === "/reset-password"
    || location === "/status"
    || location === "/explore"
    || location.startsWith("/explore")
    || location.startsWith("/hashtag/")
    || location.startsWith("/post/")
    || location.startsWith("/user/")
    || location.startsWith("/@")
    || location.startsWith("/profile/")
    || location.startsWith("/search")
    || location.startsWith("/trending")
    || location === "/create"
    || location.startsWith("/legal/")
    || location.startsWith("/sys-admin")
    || location.startsWith("/admin")
    || location.startsWith("/creator/");

  useEffect(() => {
    if (loading) return;
    /* Guests on root → send to explore instead of auth */
    if (!isAuthenticated && !isPublic) {
      if (location === "/") navigate("/explore");
      else navigate("/auth");
    }
    if (isAuthenticated && location === "/auth") navigate("/");
    /* NOTE: /explore is intentionally accessible by both guests AND
     * authenticated users — it is the public discovery feed. Do NOT
     * add a redirect away from /explore for authenticated users here. */
  }, [isAuthenticated, isPublic, loading, location, navigate]);

  if (loading) {
    /* Auth bootstrap blocks the tree, so the GlobalLoaderProvider isn't
       mounted yet — render the cinematic overlay directly so the splash
       still uses the unified loading visual. */
    return (
      <div className="app-bg" style={{ position: "fixed", inset: 0 }}>
        <CinematicLoadingOverlay open message="Loading Socia…" subtitle="Preparing your studio" />
      </div>
    );
  }

  /* Suppress the one-frame flash of the wrong page while the redirect
   * useEffect is about to fire (e.g. guest at "/" before navigating to
   * "/explore", or authed user landing on "/auth"). */
  if (!isAuthenticated && !isPublic) {
    return null;
  }

  return <>{children}</>;
}

/**
 * OwnerGuard — gates the owner-only monitoring dashboards (/owner/*).
 * AuthGuard already ensures a session exists; this additionally requires the
 * signed-in user to be the platform owner. Non-owners are redirected home so
 * the dashboards never mount (no owner-only sockets/fetches leak).
 */
function OwnerGuard({ children }: { children: React.ReactNode }) {
  const isOwner = useAppStore((s) => s.user?.isOwner === true);
  const [, navigate] = useLocation();

  useEffect(() => {
    if (!isOwner) navigate("/");
  }, [isOwner, navigate]);

  if (!isOwner) return null;
  return <>{children}</>;
}

function Router() {
  return (
    <Switch>
      <Route path="/auth"                  component={Auth} />
      <Route path="/auth/callback"         component={AuthCallback} />
      <Route path="/forgot-password"       component={ResetPassword} />
      <Route path="/reset-password"        component={ResetPassword} />
      <Route path="/"                      component={Home} />
      <Route path="/search"               component={SearchPage} />
      <Route path="/create"               component={AiAcademyMarketplace} />
      <Route path="/create/prompt-image"  component={CreatePromptImage} />
      <Route path="/create/prompt-video"  component={CreatePromptVideo} />
      <Route path="/create/image-video"   component={CreateImageVideo} />
      {/* AI Cinematic Studio + AI Preset Studio are locked behind an
          admin check until their backend models/API keys are wired up.
          ComingSoonGuard prevents the heavy page from mounting for
          non-admins, so no API calls / sockets leak from these routes. */}
      <Route path="/create/multi-frame">
        <ComingSoonGuard title="AI Cinematic Studio">
          <CreateMultiFrame />
        </ComingSoonGuard>
      </Route>
      <Route path="/studio">
        <ComingSoonGuard title="AI Preset Studio">
          <Studio />
        </ComingSoonGuard>
      </Route>
      <Route path="/studio/creations"     component={MyCreations} />
      <Route path="/studio/:presetId"     component={StudioPreset} />
      <Route path="/socia-gpt"             component={SociaGpt} />
      <Route path="/socia-gpt/billing"    component={SociaGptBilling} />
      <Route path="/messages"             component={Messages} />
      <Route path="/messages/:id"         component={ChatThread} />
      <Route path="/groups/:id"           component={GroupThread} />
      <Route path="/profile"              component={Profile} />
      <Route path="/creator/dashboard"    component={CreatorDashboard} />
      <Route path="/live/:id"             component={LiveStream} />
      <Route path="/go-live"              component={GoLive} />
      <Route path="/profile/settings"     component={Settings} />
      <Route path="/profile/:id"          component={UserProfile} />
      <Route path="/post/:id"             component={PostDetail} />
      <Route path="/followers/:id"        component={FollowersPage} />
      <Route path="/following/:id"        component={FollowingPage} />
      <Route path="/friends/:id"          component={FriendsPage} />
      <Route path="/pulse-admin"          component={PulseAdminPage} />
      <Route path="/user/:username"       component={UserByUsername} />
      <Route path="/subscribe"            component={Subscribe} />
      <Route path="/billing"              component={Billing} />
      <Route path="/billing/refund/:id"   component={RefundThread} />
      <Route path="/billing/upgrade"      component={BillingUpgrade} />
      <Route path="/billing/success"      component={BillingSuccess} />
      <Route path="/billing/cancelled"    component={BillingCancelled} />
      <Route path="/support/success"      component={SupportSuccess} />
      <Route path="/support/cancelled"    component={SupportCancelled} />
      <Route path="/subscription"         component={BillingUpgrade} />
      <Route path="/creator/monetization"  component={CreatorMonetization} />
      <Route path="/creator/affiliate"    component={AffiliateProgram} />
      <Route path="/creator/seller"       component={SellerCenter} />
      <Route path="/creator/stars"        component={CreatorStars} />
      <Route path="/upload"               component={UploadPage} />
      <Route path="/sounds/:id"           component={SoundPage} />
      <Route path="/camera"               component={CameraCreator} />
      <Route path="/explore"              component={ExplorePage} />
      <Route path="/trending"             component={TrendingPage} />
      <Route path="/hashtag/:tag"         component={HashtagFeedPage} />
      <Route path="/@:username"           component={UserByUsername} />
      <Route path="/support-hub"          component={SupportHub} />
      <Route path="/notifications"        component={SocialNotifications} />
      <Route path="/status"               component={PublicStatus} />
      <Route path="/sys-admin/login"      component={SysAdminLogin} />
      <Route path="/sys-admin"            component={SysAdminPage} />
      <Route path="/sys-admin/:rest*"     component={SysAdminPage} />
      <Route path="/owner/payments">
        <OwnerGuard><SystemStatusCenter /></OwnerGuard>
      </Route>
      <Route path="/owner/ai">
        <OwnerGuard><AICommandCenter /></OwnerGuard>
      </Route>
      <Route path="/admin/login"          component={AdminLogin} />
      <Route path="/admin/dashboard"      component={AdminDashboard} />
      <Route path="/admin"                component={AdminDashboard} />
      <Route path="/admin/:rest*"         component={AdminDashboard} />
      <Route path="/legal/terms"          component={TermsPage} />
      <Route path="/legal/privacy"        component={PrivacyPage} />
      <Route path="/legal/licenses"       component={LicensesPage} />
      <Route path="/legal/developer"      component={DeveloperPage} />
      <Route                              component={NotFound} />
    </Switch>
  );
}

/**
 * Bootstraps the super-admin session once at app startup. If a token
 * exists in localStorage we round-trip `adminFetchSession()` to
 * rehydrate the profile into `useAdminStore`; either way we flip
 * `hydrated` so gated routes (`ComingSoonGuard`) know admin status
 * has been resolved and stop holding the screen blank. Runs in a
 * `useEffect` so it never blocks first paint.
 */
function AdminSessionBootstrap() {
  useEffect(() => {
    const setHydrated = useAdminStore.getState().setHydrated;
    let cancelled = false;
    (async () => {
      if (hasAdminToken()) {
        try { await adminFetchSession(); } catch { /* invalid token already cleared */ }
      }
      if (!cancelled) setHydrated(true);
    })();
    return () => { cancelled = true; };
  }, []);
  return null;
}

function App() {
  return (
    /* UpdateGate is the OUTERMOST wrapper so the force-update screen renders
     * before any provider, route, or auth check — even if the rest of the
     * app would crash, the gate still blocks outdated installs. */
    <UpdateGate>
      <PreferencesProvider>
        <QueryClientProvider client={queryClient}>
          <TooltipProvider>
            <AuthProvider>
              {/* GlobalLoaderProvider mounts ONE cinematic loading overlay
                  at the app root so every page can call useGlobalLoader()
                  for a unified, on-brand loading experience. */}
              <GlobalLoaderProvider>
                <AdminSessionBootstrap />
                <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
                  <AuthGuard>
                    <AppShell>
                      {/* Suspense catches lazy-page loading. Fallback renders
                          inside AppShell so the top bar and bottom nav stay
                          visible while the chunk downloads. */}
                      <RouteErrorBoundary>
                        <Suspense fallback={<PageSkeleton />}>
                          <Router />
                        </Suspense>
                      </RouteErrorBoundary>
                    </AppShell>
                  </AuthGuard>
                </WouterRouter>
                {/* Single Toaster mounted at the root so any page (e.g.
                    CreateHub's coming-soon locked taps) can dispatch
                    toasts through `useToast()`. */}
                <Toaster />
                {/* Global Login-Required modal — triggered from any page via
                    useLoginGate hook when a guest attempts an AI action.
                    Backend enforces auth via requireAuth; this is the UX layer. */}
                <GlobalLoginGate />
                {/* Global AI Generation loading screen — shown ONLY during
                    AI generation tasks (image / video / cinematic). Driven by
                    the isolated useAIGeneration store; fully additive. */}
                <GlobalAIGenerationOverlay />
                {/* Premium animated launch splash — plays once on app launch,
                    then fades out to reveal the login screen. Fully additive
                    visual layer; does not touch routing or auth. */}
                <SplashScreen />
                {/* Global PULSE viewer host — listens for socia:open-pulse events */}
                <PulseViewerHost />
              </GlobalLoaderProvider>
            </AuthProvider>
          </TooltipProvider>
        </QueryClientProvider>
      </PreferencesProvider>
    </UpdateGate>
  );
}

/** Reads from the global login-gate store and renders the modal. */
function GlobalLoginGate() {
  const open      = useLoginGateStore((s) => s.open);
  const toolName  = useLoginGateStore((s) => s.toolName);
  const closeGate = useLoginGateStore((s) => s.closeGate);
  return <LoginRequiredModal open={open} onClose={closeGate} toolName={toolName} />;
}

export default App;
