import { useMemo, type CSSProperties } from "react";
import { VideoPostPlayer } from "./VideoPostPlayer";
import type { PostMedia } from "@/lib/postsClient";

type Props = {
  media: PostMedia[];
  onOpen?: (index: number) => void;
  onDoubleTap?: () => void;
  className?: string;
  preview?: boolean;
};

/**
 * X-style adaptive media layout.
 * 1 = natural ratio, 2 = side-by-side, 3 = large-left + stacked-right,
 * 4 = 2x2. The same renderer is used anywhere a post's media is displayed.
 */
export function XMediaGrid({ media, onOpen, onDoubleTap, className = "", preview = false }: Props) {
  const items = useMemo(() => media.slice(0, 4), [media]);
  if (!items.length) return null;

  const activate = (index: number) => {
    if (onOpen) onOpen(index);
  };

  const renderMedia = (item: PostMedia, index: number, fit: "cover" | "contain" = "cover") => {
    const common = {
      width: "100%",
      height: "100%",
      display: "block",
      objectFit: fit,
      background: "#0b0b0b",
    } as CSSProperties;

    return item.type === "video" ? (
      <VideoPostPlayer
        url={item.url}
        aspectRatio={item.width && item.height ? `${item.width}/${item.height}` : "16/9"}
        autoplayThreshold={preview ? 0.15 : 0.4}
      />
    ) : (
      <img src={item.url} alt="" loading="lazy" draggable={false} style={common} />
    );
  };

  const tile = (item: PostMedia, index: number, style: CSSProperties, fit: "cover" | "contain" = "cover") => (
    <div
      key={`${item.id || item.url}-${index}`}
      role={onOpen ? "button" : undefined}
      tabIndex={onOpen ? 0 : undefined}
      onClick={(e) => { e.stopPropagation(); activate(index); }}
      onDoubleClick={(e) => { e.stopPropagation(); onDoubleTap?.(); }}
      onKeyDown={(e) => { if (onOpen && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); activate(index); } }}
      aria-label={onOpen ? `Open media ${index + 1}` : undefined}
      style={{
        ...style,
        padding: 0,
        border: 0,
        margin: 0,
        overflow: "hidden",
        background: "#0b0b0b",
        cursor: onOpen ? "pointer" : "default",
        position: "relative",
      }}
    >
      {renderMedia(item, index, fit)}
    </div>
  );

  if (items.length === 1) {
    const m = items[0];
    const ratio = m.width && m.height ? `${m.width}/${m.height}` : undefined;
    return (
      <div className={className} style={{ overflow: "hidden", borderRadius: 16, background: "#0b0b0b" }}>
        <div style={{ position: "relative", width: "100%", maxHeight: 560, aspectRatio: ratio, minHeight: 180 }}>
          {tile(m, 0, { width: "100%", height: "100%" }, "contain")}
        </div>
      </div>
    );
  }

  const radius = 16;
  return (
    <div
      className={className}
      style={{
        display: "grid",
        gridTemplateColumns: items.length === 3 ? "1.35fr 1fr" : "1fr 1fr",
        gridTemplateRows: items.length === 3 ? "1fr 1fr" : "1fr 1fr",
        gap: 2,
        overflow: "hidden",
        borderRadius: radius,
        background: "#000",
        aspectRatio: items.length === 2 ? "16/9" : "16/10",
      }}
    >
      {items.length === 2 && (
        <>
          {tile(items[0], 0, { gridColumn: "1", gridRow: "1 / span 2" })}
          {tile(items[1], 1, { gridColumn: "2", gridRow: "1 / span 2" })}
        </>
      )}
      {items.length === 3 && (
        <>
          {tile(items[0], 0, { gridColumn: "1", gridRow: "1 / span 2" })}
          {tile(items[1], 1, { gridColumn: "2", gridRow: "1" })}
          {tile(items[2], 2, { gridColumn: "2", gridRow: "2" })}
        </>
      )}
      {items.length === 4 && items.map((m, i) => tile(m, i, { gridColumn: i % 2 === 0 ? "1" : "2", gridRow: i < 2 ? "1" : "2" }))}
    </div>
  );
}
