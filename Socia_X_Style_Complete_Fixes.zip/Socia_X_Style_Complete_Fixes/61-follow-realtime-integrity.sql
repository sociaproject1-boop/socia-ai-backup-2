-- Migration 61: follow integrity + realtime
-- Run once in Supabase SQL Editor. Safe to re-run.

CREATE UNIQUE INDEX IF NOT EXISTS follows_pair_unique
  ON public.follows(follower_id, following_id);

CREATE OR REPLACE FUNCTION public.follow_user(target_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF target_id IS NULL OR target_id = auth.uid() THEN RETURN; END IF;
  INSERT INTO public.follows (follower_id, following_id)
  VALUES (auth.uid(), target_id)
  ON CONFLICT (follower_id, following_id) DO NOTHING;
  IF FOUND THEN
    UPDATE public.users SET followers = COALESCE(followers, 0) + 1 WHERE id = target_id;
    UPDATE public.users SET following = COALESCE(following, 0) + 1 WHERE id = auth.uid();
  END IF;
END;
$$;

CREATE OR REPLACE FUNCTION public.unfollow_user(target_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  DELETE FROM public.follows WHERE follower_id = auth.uid() AND following_id = target_id;
  IF FOUND THEN
    UPDATE public.users SET followers = GREATEST(0, COALESCE(followers, 0) - 1) WHERE id = target_id;
    UPDATE public.users SET following = GREATEST(0, COALESCE(following, 0) - 1) WHERE id = auth.uid();
  END IF;
END;
$$;

UPDATE public.users u
SET followers = (SELECT COUNT(*) FROM public.follows f WHERE f.following_id = u.id),
    following = (SELECT COUNT(*) FROM public.follows f WHERE f.follower_id = u.id);

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_publication_tables WHERE pubname='supabase_realtime' AND schemaname='public' AND tablename='follows') THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.follows;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_publication_tables WHERE pubname='supabase_realtime' AND schemaname='public' AND tablename='users') THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.users;
  END IF;
END $$;
