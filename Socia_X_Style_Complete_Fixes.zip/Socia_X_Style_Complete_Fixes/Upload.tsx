import { useMemo, useRef, useState } from "react";
import { useLocation } from "wouter";
import { ArrowLeft, Image as ImageIcon, Video, X, Smile, MapPin, Globe2, Loader2, Plus } from "lucide-react";
import { useAppStore } from "@/lib/store";
import { createPost, uploadPostMedia, type SocialPost } from "@/lib/postsClient";

const MAX_CHARS = 500;
const MAX_FILES = 4;

type DraftMedia = { file: File; url: string; kind: "photo" | "video"; width?: number; height?: number; duration?: number };

function readMediaMeta(file: File): Promise<Pick<DraftMedia, "width" | "height" | "duration">> {
  return new Promise((resolve) => {
    const url = URL.createObjectURL(file);
    if (file.type.startsWith("video/")) {
      const v = document.createElement("video"); v.preload = "metadata";
      v.onloadedmetadata = () => { resolve({ width: v.videoWidth || undefined, height: v.videoHeight || undefined, duration: v.duration || undefined }); URL.revokeObjectURL(url); };
      v.onerror = () => { resolve({}); URL.revokeObjectURL(url); }; v.src = url;
    } else {
      const img = new Image();
      img.onload = () => { resolve({ width: img.naturalWidth || undefined, height: img.naturalHeight || undefined }); URL.revokeObjectURL(url); };
      img.onerror = () => { resolve({}); URL.revokeObjectURL(url); }; img.src = url;
    }
  });
}

export default function Upload() {
  const user = useAppStore((s) => s.user); const [, navigate] = useLocation();
  const inputRef = useRef<HTMLInputElement>(null);
  const [text, setText] = useState(""); const [media, setMedia] = useState<DraftMedia[]>([]); const [posting, setPosting] = useState(false); const [error, setError] = useState("");
  const remaining = MAX_CHARS - text.length; const canPost = !posting && remaining >= 0 && (!!text.trim() || media.length > 0); const mediaGrid = useMemo(() => media.length, [media]);
  async function addFiles(files: FileList | File[]) {
    const selected = Array.from(files).filter((f) => f.type.startsWith("image/") || f.type.startsWith("video/")).slice(0, Math.max(0, MAX_FILES - media.length));
    const next: DraftMedia[] = []; for (const file of selected) { const meta = await readMediaMeta(file); next.push({ file, url: URL.createObjectURL(file), kind: file.type.startsWith("video/") ? "video" : "photo", ...meta }); }
    if (next.length) setMedia((prev) => [...prev, ...next]);
  }
  function removeMedia(index: number) { setMedia((prev) => { const item = prev[index]; if (item) URL.revokeObjectURL(item.url); return prev.filter((_, i) => i !== index); }); }
  async function publish() {
    if (!canPost || !user?.id) return; setPosting(true); setError("");
    try {
      const uploaded: { url: string; type: "photo" | "video"; width?: number; height?: number; duration?: number }[] = [];
      for (const item of media) uploaded.push({ url: await uploadPostMedia(item.file, user.id), type: item.kind, width: item.width, height: item.height, duration: item.duration });
      const type = uploaded.length > 1 ? "multi" : uploaded[0]?.type ?? "photo";
      const post: SocialPost = await createPost({ caption: text.trim() || undefined, type, media: uploaded });
      media.forEach((m) => URL.revokeObjectURL(m.url)); setMedia([]); setText(""); navigate(`/post/${post.id}`);
    } catch (e) { setError(e instanceof Error ? e.message : "Failed to publish post."); } finally { setPosting(false); }
  }
  return (
    <div className="flex h-full min-h-0 flex-col bg-black text-white">
      <header className="flex shrink-0 items-center gap-3 px-4 py-3" style={{ paddingTop: "calc(env(safe-area-inset-top,0px) + 10px)" }}>
        <button onClick={() => navigate("/")} disabled={posting} className="grid h-9 w-9 place-items-center rounded-full text-white/90 active:bg-white/10"><ArrowLeft className="h-5 w-5" /></button>
        <h1 className="flex-1 text-[16px] font-bold">Create post</h1>
        <button onClick={publish} disabled={!canPost} className="rounded-full px-4 py-2 text-[13px] font-bold text-white disabled:opacity-40" style={{ background: "#1D9BF0" }}>{posting ? <Loader2 className="h-4 w-4 animate-spin" /> : "Post"}</button>
      </header>
      <main className="min-h-0 flex-1 overflow-y-auto px-4 pb-24">
        <div className="flex gap-3 pt-2">
          {user?.avatar ? <img src={user.avatar} alt="" className="h-10 w-10 shrink-0 rounded-full object-cover" /> : <div className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-[#1D9BF0] font-bold">{(user?.name || user?.handle || "?")[0]}</div>}
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2"><span className="text-[15px] font-bold">{user?.name || user?.handle || "You"}</span><span className="flex items-center gap-1 rounded-full bg-white/[0.08] px-2 py-0.5 text-[11px] font-semibold text-white/75"><Globe2 className="h-3 w-3" /> Everyone</span></div>
            <textarea value={text} onChange={(e) => setText(e.target.value)} placeholder="What's happening?" rows={4} maxLength={MAX_CHARS} autoFocus className="mt-3 min-h-[130px] w-full resize-none bg-transparent text-[18px] leading-6 text-white placeholder:text-white/30 outline-none" />
          </div>
        </div>
        {media.length > 0 && (
          <div className="mt-2 overflow-hidden rounded-2xl bg-[#0b0b0b]">
            <div
              className={mediaGrid === 1 ? "grid grid-cols-1" : mediaGrid === 2 ? "grid grid-cols-2 gap-0.5" : mediaGrid === 3 ? "grid grid-cols-[1.35fr_1fr] grid-rows-2 gap-0.5" : "grid grid-cols-2 grid-rows-2 gap-0.5"}
              style={{ aspectRatio: mediaGrid === 1 ? undefined : mediaGrid === 2 ? "16/9" : "16/10" }}
            >
              {media.map((item, i) => (
                <div
                  key={item.url}
                  className={`relative min-h-0 overflow-hidden bg-[#0d0d0d] ${mediaGrid === 1 ? "max-h-[560px]" : ""}`}
                  style={mediaGrid === 3 && i === 0 ? { gridRow: "1 / span 2" } : undefined}
                >
                  {item.kind === "video" ? (
                    <video src={item.url} controls playsInline muted className="h-full w-full object-cover" />
                  ) : (
                    <img src={item.url} alt="" className={`h-full w-full ${mediaGrid === 1 ? "object-contain" : "object-cover"}`} />
                  )}
                  <button onClick={() => removeMedia(i)} aria-label={`Remove media ${i + 1}`} className="absolute right-2 top-2 grid h-8 w-8 place-items-center rounded-full bg-black/70 text-white shadow-lg">
                    <X className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
        {error && <div className="mt-3 rounded-xl bg-red-500/10 px-3 py-2 text-xs text-red-300">{error}</div>}
      </main>
      <footer className="flex shrink-0 items-center gap-1 bg-black px-4 py-3" style={{ paddingBottom: "max(env(safe-area-inset-bottom,0px),12px)" }}>
        <input ref={inputRef} type="file" accept="image/*,video/*" multiple hidden onChange={(e) => { if (e.target.files) void addFiles(e.target.files); e.currentTarget.value = ""; }} />
        <button onClick={() => inputRef.current?.click()} disabled={media.length >= MAX_FILES || posting} className="grid h-10 w-10 place-items-center rounded-full text-[#1D9BF0] disabled:opacity-30"><ImageIcon className="h-5 w-5" /></button>
        <button onClick={() => inputRef.current?.click()} disabled={media.length >= MAX_FILES || posting} className="grid h-10 w-10 place-items-center rounded-full text-[#1D9BF0] disabled:opacity-30"><Video className="h-5 w-5" /></button>
        <button className="grid h-10 w-10 place-items-center rounded-full text-[#1D9BF0]"><Smile className="h-5 w-5" /></button>
        <button className="grid h-10 w-10 place-items-center rounded-full text-[#1D9BF0]"><MapPin className="h-5 w-5" /></button>
        <div className="ml-auto flex items-center gap-2"><span className="text-[11px] text-white/35">{remaining}</span><Plus className="h-4 w-4 text-white/20" /></div>
      </footer>
    </div>
  );
}
