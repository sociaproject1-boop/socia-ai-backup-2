-- Migration 62: X-style reposts + share-to-Socia feed actions.
-- Run after the social post/share migrations.

CREATE TABLE IF NOT EXISTS public.reposts (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id    uuid NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
  user_id    uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (post_id, user_id)
);

ALTER TABLE public.reposts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Reposts public read" ON public.reposts;
CREATE POLICY "Reposts public read"
  ON public.reposts FOR SELECT USING (true);

DROP POLICY IF EXISTS "Users manage own reposts" ON public.reposts;
CREATE POLICY "Users manage own reposts"
  ON public.reposts FOR ALL
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE INDEX IF NOT EXISTS idx_reposts_created_at ON public.reposts(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_reposts_user_created ON public.reposts(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_reposts_post ON public.reposts(post_id, created_at DESC);

ALTER TABLE public.posts
  ADD COLUMN IF NOT EXISTS repost_count integer NOT NULL DEFAULT 0;

CREATE OR REPLACE FUNCTION public.fn_sync_repost_count()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.posts SET repost_count = repost_count + 1 WHERE id = NEW.post_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE public.posts SET repost_count = GREATEST(0, repost_count - 1) WHERE id = OLD.post_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS trg_sync_repost_count_insert ON public.reposts;
DROP TRIGGER IF EXISTS trg_sync_repost_count_delete ON public.reposts;
CREATE TRIGGER trg_sync_repost_count_insert
  AFTER INSERT ON public.reposts
  FOR EACH ROW EXECUTE FUNCTION public.fn_sync_repost_count();
CREATE TRIGGER trg_sync_repost_count_delete
  AFTER DELETE ON public.reposts
  FOR EACH ROW EXECUTE FUNCTION public.fn_sync_repost_count();

-- Repair any pre-existing drift if the migration is rerun.
UPDATE public.posts p
SET repost_count = COALESCE((SELECT count(*)::integer FROM public.reposts r WHERE r.post_id = p.id), 0);

-- Allow the social notification center to show repost activity.
ALTER TABLE public.post_notifications DROP CONSTRAINT IF EXISTS post_notifications_type_check;
ALTER TABLE public.post_notifications
  ADD CONSTRAINT post_notifications_type_check
  CHECK (type IN ('like','comment','reply','follow','mention','stars','share','repost'));

-- Realtime keeps the repost state/count synchronized across open clients.
DO $$
BEGIN
  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.reposts;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;
END $$;

-- Ensure all engagement tables used by the live feed are in Realtime.
DO $$
DECLARE
  t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['public.posts','public.likes','public.saves','public.comments','public.reposts'] LOOP
    BEGIN
      EXECUTE format('ALTER PUBLICATION supabase_realtime ADD TABLE %s', t);
    EXCEPTION WHEN duplicate_object THEN NULL;
    END;
  END LOOP;
END $$;
