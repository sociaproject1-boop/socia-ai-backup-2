/**
 * routes/socialPosts.ts — Complete social feed system.
 *
 * Sections:
 *   §1  Feed endpoints: for-you, following, saved, user, single post
 *   §2  Post CRUD: create, delete (owner can delete any)
 *   §3  Like / save toggles with notification triggers
 *   §4  Comment CRUD: list, add, edit, delete, replies
 *   §5  Reports: post + comment
 *   §6  View counter
 *   §7  Notifications: list, mark read, unread count
 *   §8  Owner moderation: review reports, delete any post/comment
 *
 * All feed responses include `has_liked` and `has_saved` when an authenticated
 * viewer is present (optional auth via tryGetViewer).
 */
import { Router, type IRouter } from "express";
import { createClient } from "../lib/dbCompat.js";
import { requireAuth, getAuthedUser } from "../lib/replitAuth.js";
import { logger } from "../lib/logger.js";

const OWNER_EMAIL = (process.env["OWNER_EMAIL"] ?? "allanalbacen5@gmail.com").toLowerCase();

function db() {
  const url = process.env["VITE_SUPABASE_URL"] ?? process.env["SUPABASE_URL"] ?? "";
  const key = process.env["SUPABASE_SERVICE_ROLE_KEY"] ?? process.env["SUPABASE_ANON_KEY"] ?? "";
  return createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

const router: IRouter = Router();

/* ── Helpers ────────────────────────────────────────────────────────────── */

/** Read authenticated user ID without failing (returns null if no session). */
function tryGetViewer(req: any): string | null {
  try { return getAuthedUser(req).id; } catch { return null; }
}

function isOwnerUser(req: any): boolean {
  try { return (getAuthedUser(req).email ?? "").toLowerCase() === OWNER_EMAIL; } catch { return false; }
}

const BASE_POST_SELECT = `id, author_id, caption, type, view_count, created_at, updated_at, sound_id`;

/** Enrich posts with real aggregate counts + author profiles + media + viewer like/save status + sound metadata.
 *
 * Six parallel queries per batch:
 *   likes, comments, saves, sounds — engagement aggregates
 *   users  — author profiles (via dbCompat → heliumdb)
 *   post_media — media rows (via dbCompat → Supabase PostgREST)
 *
 * Author and media are fetched in the same round-trip as engagement data so
 * the response always includes full profile info and media — no FK-join dependency.
 */
async function enrichPosts(posts: any[], viewerId: string | null) {
  if (!posts.length) return [];

  const svc = db();
  const postIds   = posts.map((p: any) => p.id);
  const authorIds = [...new Set(posts.map((p: any) => p.author_id).filter(Boolean))];
  const soundIds  = [...new Set(posts.map((p: any) => p.sound_id).filter(Boolean))];

  const [likesRes, commentsRes, savesRes, repostsRes, soundsRes, authorsRes, mediaRes] = await Promise.all([
    svc.from("likes").select("post_id, user_id").in("post_id", postIds),
    svc.from("comments").select("post_id").in("post_id", postIds),
    svc.from("saves").select("post_id, user_id").in("post_id", postIds),
    svc.from("reposts").select("post_id, user_id").in("post_id", postIds),
    soundIds.length > 0
      ? svc.from("sounds").select("id, title, cover_image, audio_url, usage_count, creator_id").in("id", soundIds)
      : Promise.resolve({ data: [] as any[] }),
    authorIds.length > 0
      ? svc.from("users").select("id, name, username, avatar_url, is_verified, is_owner, subscription_status").in("id", authorIds)
      : Promise.resolve({ data: [] as any[] }),
    postIds.length > 0
      ? svc.from("post_media").select("id, post_id, url, type, width, height, duration, position").in("post_id", postIds)
      : Promise.resolve({ data: [] as any[] }),
  ]);

  const authorMap  = new Map<string, any>();
  const mediaByPost = new Map<string, any[]>();
  const soundMap   = new Map<string, any>();
  const likeMap    = new Map<string, number>();
  const commentMap = new Map<string, number>();
  const saveMap    = new Map<string, number>();
  const likedSet   = new Set<string>();
  const savedSet   = new Set<string>();
  const repostedSet = new Set<string>();
  const repostCountMap = new Map<string, number>();

  (authorsRes.data  ?? []).forEach((u: any) => authorMap.set(u.id, u));
  (mediaRes.data    ?? []).forEach((m: any) => {
    const arr = mediaByPost.get(m.post_id) ?? [];
    arr.push(m);
    mediaByPost.set(m.post_id, arr);
  });
  (soundsRes.data   ?? []).forEach((s: any) => soundMap.set(s.id, s));
  (likesRes.data    ?? []).forEach((r: any) => {
    likeMap.set(r.post_id, (likeMap.get(r.post_id) ?? 0) + 1);
    if (viewerId && r.user_id === viewerId) likedSet.add(r.post_id);
  });
  (commentsRes.data ?? []).forEach((r: any) => commentMap.set(r.post_id, (commentMap.get(r.post_id) ?? 0) + 1));
  (repostsRes.data ?? []).forEach((r: any) => {
    repostCountMap.set(r.post_id, (repostCountMap.get(r.post_id) ?? 0) + 1);
    if (viewerId && r.user_id === viewerId) repostedSet.add(r.post_id);
  });
  (savesRes.data    ?? []).forEach((r: any) => {
    saveMap.set(r.post_id, (saveMap.get(r.post_id) ?? 0) + 1);
    if (viewerId && r.user_id === viewerId) savedSet.add(r.post_id);
  });

  return posts.map((p: any) => ({
    ...p,
    author:        authorMap.get(p.author_id) ?? null,
    like_count:    likeMap.get(p.id) ?? 0,
    comment_count: commentMap.get(p.id) ?? 0,
    save_count:    saveMap.get(p.id) ?? 0,
    has_liked:     likedSet.has(p.id),
    has_saved:     savedSet.has(p.id),
    has_reposted:  repostedSet.has(p.id),
    repost_count:  repostCountMap.get(p.id) ?? 0,
    media:         (mediaByPost.get(p.id) ?? []).sort((a: any, b: any) => a.position - b.position),
    sound:         p.sound_id ? (soundMap.get(p.sound_id) ?? null) : null,
  }));
}

/**
 * Add X-style repost items to a feed. The original post remains the canonical
 * object for likes/comments/media; reposted_by only changes the feed context.
 * We replace a matching original in the same page rather than duplicating it.
 */
async function withReposts(posts: any[], viewerId: string | null, allowedReposterIds?: string[]) {
  const svc = db();
  let query = svc
    .from("reposts")
    .select("post_id, user_id, created_at")
    .order("created_at", { ascending: false })
    .limit(100);

  if (allowedReposterIds && allowedReposterIds.length > 0) {
    query = query.in("user_id", allowedReposterIds);
  } else if (allowedReposterIds && allowedReposterIds.length === 0) {
    return posts;
  }

  const { data: rows } = await query;
  if (!rows?.length) return posts;

  const existing = new Set(posts.map((p: any) => p.id));
  const candidates = rows.filter((r: any) => !existing.has(r.post_id));
  if (!candidates.length) return posts;

  const postIds = [...new Set(candidates.map((r: any) => r.post_id))];
  const { data: originals } = await svc
    .from("posts")
    .select(BASE_POST_SELECT)
    .in("id", postIds);
  if (!originals?.length) return posts;

  const enriched = await enrichPosts(originals as any[], viewerId);
  const originalMap = new Map(enriched.map((p: any) => [p.id, p]));
  const reposterIds = [...new Set(candidates.map((r: any) => r.user_id))];
  const { data: reposters } = await svc
    .from("users")
    .select("id, name, username, avatar_url, is_verified, is_owner")
    .in("id", reposterIds);
  const reposterMap = new Map((reposters ?? []).map((u: any) => [u.id, u]));

  const repostItems = candidates
    .map((r: any) => {
      const original = originalMap.get(r.post_id);
      const reposter = reposterMap.get(r.user_id);
      if (!original || !reposter) return null;
      return {
        ...original,
        reposted_by: reposter,
        reposted_at: r.created_at,
      };
    })
    .filter(Boolean) as any[];

  return [...posts, ...repostItems]
    .sort((a: any, b: any) => new Date(b.reposted_at ?? b.created_at).getTime() - new Date(a.reposted_at ?? a.created_at).getTime())
    .slice(0, Math.max(posts.length, 50));
}

/** Engagement score for trending sort (applied in Node, not in DB). */
function trendingScore(p: any): number {
  const likes    = Number(p.like_count ?? 0);
  const comments = Number(p.comment_count ?? 0);
  const saves    = Number(p.save_count ?? 0);
  const views    = Number(p.view_count ?? 0);
  const ageHours = (Date.now() - new Date(p.created_at).getTime()) / 3_600_000;
  const recency  = Math.max(0, 1 - ageHours / 168); // decay over 7 days
  return likes * 3 + comments * 5 + saves * 4 + Math.min(views / 100, 50) + recency * 20;
}

/** Fire a notification async — never blocks the response. */
async function fireNotification(payload: {
  user_id:    string;
  actor_id:   string;
  post_id?:   string;
  comment_id?: string;
  type:       "like" | "comment" | "reply" | "follow" | "mention" | "stars" | "share" | "repost";
}) {
  /* Don't notify yourself */
  if (payload.user_id === payload.actor_id) return;
  try {
    await db().from("post_notifications").insert(payload);
  } catch (err) {
    logger.warn({ err }, "[notifications] insert failed (non-critical)");
  }
}

/* ════════════════════════════════════════════════════════════════════════════════
   §1  FEED ENDPOINTS
═════════════════════════════════════════════════════════════════════════════════ */

/* ── GET /api/posts — For You feed (public + optional viewer) ──────────────── */
router.get("/posts", async (req, res) => {
  try {
    const viewer = tryGetViewer(req);
    const limit  = Math.min(Number(req.query["limit"] ?? 15), 50);
    const offset = Number(req.query["offset"] ?? 0);
    const sort   = req.query["sort"] as string | undefined; // "trending" | "newest"
    const svc    = db();

    /* C-2/C-3: fetch exactly the requested page — no over-fetching.
     * Trending sort is applied in-memory on the page returned by the DB,
     * which preserves correct pagination (no double-offset bug) and avoids
     * fetching up to 5× more rows than needed. */
    const { data, error } = await svc
      .from("posts")
      .select(BASE_POST_SELECT)
      .order("created_at", { ascending: false })
      .range(offset, offset + limit - 1);

    if (error) {
      logger.error({ err: error }, "[posts] select error");
      res.status(500).json({ error: error.message ?? "Database error" });
      return;
    }

    logger.info({
  firstPost: data?.[0]
}, "[DEBUG] First post");

    let posts = await enrichPosts(data ?? [], viewer);

    posts = await withReposts(posts, viewer);
    if (sort === "trending") {
      posts = posts.sort((a, b) => trendingScore(b) - trendingScore(a));
    }

    res.json({ posts: posts.slice(0, limit) });
  } catch (err) {
    logger.error({ err }, "[posts] feed error");
    res.status(500).json({ error: "Internal error" });
  }
});

/* ── GET /api/posts/feed/following — Following feed ────────────────────────── */
router.get("/posts/feed/following", requireAuth as any, async (req, res) => {
  try {
    const viewer = getAuthedUser(req as any);
    const limit  = Math.min(Number(req.query["limit"] ?? 15), 50);
    const offset = Number(req.query["offset"] ?? 0);
    const svc    = db();

    /* Get followed user IDs */
    const { data: follows } = await svc
      .from("follows")
      .select("following_id")
      .eq("follower_id", viewer.id);

    const followedIds = (follows ?? []).map((f: any) => f.following_id);

    if (followedIds.length === 0) {
      res.json({ posts: [] });
      return;
    }

    const { data, error } = await svc
      .from("posts")
      .select(BASE_POST_SELECT)
      .in("author_id", followedIds)
      .order("created_at", { ascending: false })
      .range(offset, offset + limit - 1);

    if (error) { 
      logger.error({ err: error }, "[posts/following] select error");
      res.status(500).json({ error: error.message ?? "Database error" }); 
      return; 
    }

    let posts = await enrichPosts(data ?? [], viewer.id);
    posts = await withReposts(posts, viewer.id, [...followedIds, viewer.id]);
    res.json({ posts: posts.slice(0, limit) });
  } catch (err) {
    logger.error({ err }, "[posts/following] error");
    res.status(500).json({ error: "Internal error" });
  }
});

/* ── GET /api/posts/feed/saved — Saved posts ────────────────────────────────── */
router.get("/posts/feed/saved", requireAuth as any, async (req, res) => {
  try {
    const viewer = getAuthedUser(req as any);
    const limit  = Math.min(Number(req.query["limit"] ?? 15), 50);
    const offset = Number(req.query["offset"] ?? 0);
    const svc    = db();

    const { data: saves } = await svc
      .from("saves")
      .select("post_id")
      .eq("user_id", viewer.id)
      .order("created_at", { ascending: false })
      .range(offset, offset + limit - 1);

    const savedIds = (saves ?? []).map((s: any) => s.post_id);
    if (savedIds.length === 0) { res.json({ posts: [] }); return; }

    const { data, error } = await svc
      .from("posts")
      .select(BASE_POST_SELECT)
      .in("id", savedIds);

    if (error) { 
      logger.error({ err: error }, "[posts/saved] select error");
      res.status(500).json({ error: error.message ?? "Database error" }); 
      return; 
    }

    const posts = await enrichPosts(data ?? [], viewer.id);
    /* Preserve save order */
    const ordered = savedIds
      .map((id: string) => posts.find((p: { id: string }) => p.id === id))
      .filter(Boolean);
    res.json({ posts: ordered });
  } catch (err) {
    logger.error({ err }, "[posts/saved] error");
    res.status(500).json({ error: "Internal error" });
  }
});

/* ── GET /api/posts/user/:uid — Posts by a specific user ───────────────── */
router.get("/posts/user/:uid", async (req, res) => {
  try {
    const viewer = tryGetViewer(req);
    const { uid } = req.params;
    const limit   = Math.min(Number(req.query["limit"] ?? 20), 50);
    const offset  = Number(req.query["offset"] ?? 0);
    const svc     = db();

    const { data, error } = await svc
      .from("posts")
      .select(BASE_POST_SELECT)
      .eq("author_id", uid)
      .order("created_at", { ascending: false })
      .range(offset, offset + limit - 1);

    if (error) { 
      logger.error({ err: error }, "[posts/user] select error");
      res.status(500).json({ error: error.message ?? "Database error" }); 
      return; 
    }

    let posts = await enrichPosts(data ?? [], viewer);
    posts = await withReposts(posts, viewer, [uid]);
    res.json({ posts: posts.slice(0, limit) });
  } catch (err) {
    logger.error({ err }, "[posts/user] error");
    res.status(500).json({ error: "Internal error" });
  }
});

/* ── GET /api/posts/:id — Single post ──────────────────────────────────── */
router.get("/posts/:id", async (req, res) => {
  try {
    const viewer = tryGetViewer(req);
    const svc    = db();

    const { data, error } = await svc
      .from("posts")
      .select(BASE_POST_SELECT)
      .eq("id", req.params["id"])
      .maybeSingle();

    if (error || !data) { 
      logger.warn({ err: error }, "[posts/:id] select error or not found");
      res.status(404).json({ error: "Not found" }); 
      return; 
    }

    const [enriched] = await enrichPosts([data], viewer);
    res.json({ post: enriched });
  } catch (err) {
    logger.error({ err }, "[posts/:id] error");
    res.status(500).json({ error: "Internal error" });
  }
});

/* ════════════════════════════════════════════════════════════════════════════════
   §2  POST CRUD
═════════════════════════════════════════════════════════════════════════════════ */

/* ── POST /api/posts — Create ──────────────────────────────────────────── */
router.post("/posts", requireAuth as any, async (req, res) => {
  try {
    const user = getAuthedUser(req as any);
    const svc  = db();
    const { caption, type = "photo", media = [], sound_id } = req.body ?? {};
    // sound_id requires migration 53 (sound_id column on posts). Tracked below in try/catch.

    const trimmedCaption = caption?.trim() ?? null;
    if ((!media || media.length === 0) && !trimmedCaption) {
      res.status(400).json({ error: "A caption or at least one media item is required" });
      return;
    }

    const { data: post, error: postErr } = await svc
      .from("posts")
      .insert({ author_id: user.id, caption: caption?.trim() ?? null, type })
      .select()
      .single();

    if (postErr) { 
      logger.error({ err: postErr }, "[posts] create insert error");
      res.status(500).json({ error: postErr.message }); 
      return; 
    }

    const mediaRows = (media as any[]).map((m, i) => ({
      post_id: (post as any).id, url: m.url, type: m.type,
      width: m.width ?? null, height: m.height ?? null,
      duration: m.duration ?? null, position: i,
    }));
    if (mediaRows.length > 0) {
      await svc.from("post_media").insert(mediaRows);
    }

    /* Track sound usage after post creation */
    if (sound_id && (post as any)?.id) {
      void (async () => {
        try {
          await svc.from("sound_usage").upsert(
            { sound_id, post_id: (post as any).id, user_id: user.id },
            { onConflict: "sound_id,post_id" }
          );
          const { data: s } = await svc.from("sounds").select("usage_count").eq("id", sound_id).single();
          if (s) await svc.from("sounds").update({ usage_count: ((s as any).usage_count ?? 0) + 1 }).eq("id", sound_id);
        } catch (e) { logger.warn({ e }, "[posts] sound usage track failed (non-critical)"); }
      })();
    }

    /* Fire mention notifications — non-blocking */
    if (trimmedCaption) {
      void (async () => {
        try {
          const handles = [
            ...new Set(
              (trimmedCaption.match(/@([\w.]+)/g) ?? []).map((m: string) =>
                m.slice(1).toLowerCase(),
              ),
            ),
          ];
          for (const handle of handles) {
            const { data: mu } = await svc
              .from("users")
              .select("id")
              .ilike("username", handle)
              .limit(1)
              .maybeSingle();
            if (mu) {
              void fireNotification({
                user_id:  (mu as any).id,
                actor_id: user.id,
                post_id:  (post as any).id,
                type:     "mention",
              });
            }
          }
        } catch (e) {
          logger.warn({ e }, "[posts] mention notifications failed (non-critical)");
        }
      })();
    }

    /* Return full enriched post */
    const { data: fullPost } = await svc
      .from("posts")
      .select(BASE_POST_SELECT)
      .eq("id", (post as any).id)
      .maybeSingle();

    const [enriched] = await enrichPosts([fullPost], user.id);
    logger.info({ postId: enriched.id, userId: user.id }, "[posts] created");
    res.status(201).json({ post: enriched });
  } catch (err) {
    logger.error({ err }, "[posts] create error");
    res.status(500).json({ error: "Internal error" });
  }
});

/* ── DELETE /api/posts/:id — Author or owner can delete ────────────────── */
router.delete("/posts/:id", requireAuth as any, async (req, res) => {
  try {
    const user = getAuthedUser(req as any);
    const svc  = db();
    const postId = req.params["id"];

    const { data: post } = await svc.from("posts").select("author_id").eq("id", postId).maybeSingle();
    if (!post) { res.status(404).json({ error: "Not found" }); return; }

    const canDelete = (post as any).author_id === user.id ||
      (user.email ?? "").toLowerCase() === OWNER_EMAIL;

    if (!canDelete) { res.status(403).json({ error: "Forbidden" }); return; }

    await svc.from("posts").delete().eq("id", postId);
    res.json({ ok: true });
  } catch (err) {
    logger.error({ err }, "[posts] delete error");
    res.status(500).json({ error: "Internal error" });
  }
});

/* ════════════════════════════════════════════════════════════════════════════════
   §3  LIKE / SAVE TOGGLES
═════════════════════════════════════════════════════════════════════════════════ */

/* ── POST /api/posts/:id/like — Toggle like ────────────────────────────── */
router.post("/posts/:id/like", requireAuth as any, async (req, res) => {
  try {
    const user   = getAuthedUser(req as any);
    const svc    = db();
    const postId = req.params["id"];

    const { data: existing } = await svc
      .from("likes")
      .select("post_id")
      .eq("post_id", postId)
      .eq("user_id", user.id)
      .maybeSingle();

    if (existing) {
      await svc.from("likes").delete().eq("post_id", postId).eq("user_id", user.id);
      res.json({ liked: false });
    } else {
      await svc.from("likes").insert({ post_id: postId, user_id: user.id });

      /* Fire notification async */
      const { data: postRow } = await svc.from("posts").select("author_id").eq("id", postId).maybeSingle();
      if (postRow) {
        void fireNotification({ user_id: (postRow as any).author_id, actor_id: user.id, post_id: postId, type: "like" });
      }
      res.json({ liked: true });
    }
  } catch (err) {
    logger.error({ err }, "[posts/like] error");
    res.status(500).json({ error: "Internal error" });
  }
});

/* ── POST /api/posts/:id/save — Toggle save ────────────────────────────── */
router.post("/posts/:id/save", requireAuth as any, async (req, res) => {
  try {
    const user   = getAuthedUser(req as any);
    const svc    = db();
    const postId = req.params["id"];

    const { data: existing } = await svc
      .from("saves")
      .select("post_id")
      .eq("post_id", postId)
      .eq("user_id", user.id)
      .maybeSingle();

    if (existing) {
      await svc.from("saves").delete().eq("post_id", postId).eq("user_id", user.id);
      res.json({ saved: false });
    } else {
      await svc.from("saves").insert({ post_id: postId, user_id: user.id });
      res.json({ saved: true });
    }
  } catch (err) {
    logger.error({ err }, "[posts/save] error");
    res.status(500).json({ error: "Internal error" });
  }
});

/* ── POST /api/posts/:id/repost — X-style repost toggle ──────────────── */
router.post("/posts/:id/repost", requireAuth as any, async (req, res) => {
  try {
    const user = getAuthedUser(req as any);
    const svc = db();
    const postId = req.params["id"];

    const { data: post } = await svc.from("posts").select("id, author_id").eq("id", postId).maybeSingle();
    if (!post) { res.status(404).json({ error: "Post not found" }); return; }

    const { data: existing } = await svc
      .from("reposts")
      .select("id")
      .eq("post_id", postId)
      .eq("user_id", user.id)
      .maybeSingle();

    if (existing) {
      await svc.from("reposts").delete().eq("id", (existing as any).id);
      const { count } = await svc.from("reposts").select("id", { count: "exact", head: true }).eq("post_id", postId);
      res.json({ reposted: false, repost_count: count ?? 0 });
      return;
    }

    const { error } = await svc.from("reposts").insert({ post_id: postId, user_id: user.id });
    if (error) { res.status(500).json({ error: error.message }); return; }

    if ((post as any).author_id !== user.id) {
      void fireNotification({ user_id: (post as any).author_id, actor_id: user.id, post_id: postId, type: "repost" });
    }
    const { count } = await svc.from("reposts").select("id", { count: "exact", head: true }).eq("post_id", postId);
    res.json({ reposted: true, repost_count: count ?? 0 });
  } catch (err) {
    logger.error({ err }, "[posts/repost] error");
    res.status(500).json({ error: "Internal error" });
  }
});

/* ── POST /api/posts/:id/share — record a share event ------------------ */
router.post("/posts/:id/share", requireAuth as any, async (req, res) => {
  try {
    const user = getAuthedUser(req as any);
    const svc = db();
    const postId = req.params["id"];
    const { data: post } = await svc.from("posts").select("id, author_id").eq("id", postId).maybeSingle();
    if (!post) { res.status(404).json({ error: "Post not found" }); return; }
    const { error } = await svc.from("shares").insert({ post_id: postId, user_id: user.id });
    if (error) { res.status(500).json({ error: error.message }); return; }
    if ((post as any).author_id !== user.id) {
      void fireNotification({ user_id: (post as any).author_id, actor_id: user.id, post_id: postId, type: "share" });
    }
    const { count } = await svc.from("shares").select("id", { count: "exact", head: true }).eq("post_id", postId);
    res.json({ shared: true, share_count: count ?? 0 });
  } catch (err) {
    logger.error({ err }, "[posts/share] error");
    res.status(500).json({ error: "Internal error" });
  }
});

/* ════════════════════════════════════════════════════════════════════════════════
   §4  COMMENTS
═════════════════════════════════════════════════════════════════════════════════ */

/** Fetch author profiles for a list of comment rows and attach them as `author`. */
async function attachCommentAuthors(comments: any[]): Promise<any[]> {
  if (!comments.length) return comments;
  const authorIds = [...new Set(comments.map((c: any) => c.author_id).filter(Boolean))];
  const { data: users } = await db()
    .from("users")
    .select("id, name, username, avatar_url")
    .in("id", authorIds);
  const userMap: Record<string, any> = {};
  for (const u of (users as any[] ?? [])) userMap[u.id] = u;
  return comments.map((c: any) => ({ ...c, author: userMap[c.author_id] ?? null }));
}

/* ── GET /api/posts/:id/comments ───────────────────────────────────────── */
router.get("/posts/:id/comments", async (req, res) => {
  try {
    const svc    = db();
    const limit  = Math.min(Number(req.query["limit"] ?? 50), 100);
    const offset = Number(req.query["offset"] ?? 0);
    const parentId = req.query["parentId"] as string | undefined;

    let query = svc
      .from("comments")
      .select("*")
      .eq("post_id", req.params["id"])
      .order("created_at", { ascending: true })
      .range(offset, offset + limit - 1);

    if (parentId) {
      query = query.eq("parent_comment_id", parentId);
    } else {
      query = query.is("parent_comment_id", null); // top-level only
    }

    const { data, error } = await query;
    if (error) { 
      logger.error({ err: error }, "[posts/comments] select error");
      res.status(500).json({ error: error.message }); 
      return; 
    }
    const comments = await attachCommentAuthors(data as any[] ?? []);
    res.json({ comments });
  } catch (err) {
    logger.error({ err }, "[posts/comments] error");
    res.status(500).json({ error: "Internal error" });
  }
});

/* ── POST /api/posts/:id/comments — Add comment or reply ──────────────── */
router.post("/posts/:id/comments", requireAuth as any, async (req, res) => {
  try {
    const user   = getAuthedUser(req as any);
    const svc    = db();
    const postId = req.params["id"];
    const { content, parent_comment_id } = req.body ?? {};

    if (!content?.trim()) { res.status(400).json({ error: "Content required" }); return; }
    if (content.trim().length > 2000) { res.status(422).json({ error: "Comment too long (max 2000 chars)" }); return; }

    const { data, error } = await svc
      .from("comments")
      .insert({
        post_id: postId,
        author_id: user.id,
        content: content.trim(),
        parent_comment_id: parent_comment_id ?? null,
      })
      .select("*")
      .single();

    if (error) { 
      logger.error({ err: error }, "[posts/comments] insert error");
      res.status(500).json({ error: error.message }); 
      return; 
    }

    /* Notification async */
    const { data: postRow } = await svc.from("posts").select("author_id").eq("id", postId).maybeSingle();
    if (postRow) {
      if (parent_comment_id) {
        /* Reply notification to comment author */
        const { data: parentComment } = await svc.from("comments").select("author_id").eq("id", parent_comment_id).maybeSingle();
        if (parentComment) {
          void fireNotification({ user_id: (parentComment as any).author_id, actor_id: user.id, post_id: postId, comment_id: (data as any).id, type: "reply" });
        }
      } else {
        void fireNotification({ user_id: (postRow as any).author_id, actor_id: user.id, post_id: postId, comment_id: (data as any).id, type: "comment" });
      }
    }

    const [withAuthor] = await attachCommentAuthors([data as any]);
    res.status(201).json({ comment: withAuthor ?? data });
  } catch (err) {
    logger.error({ err }, "[posts/comments] error");
    res.status(500).json({ error: "Internal error" });
  }
});

/* ── PUT /api/posts/:id/comments/:cid — Edit own comment ──────────────── */
router.put("/posts/:id/comments/:cid", requireAuth as any, async (req, res) => {
  try {
    const user = getAuthedUser(req as any);
    const svc  = db();
    const { cid } = req.params;
    const { content } = req.body ?? {};

    if (!content?.trim()) { res.status(400).json({ error: "Content required" }); return; }

    const { data: existing } = await svc.from("comments").select("author_id").eq("id", cid).maybeSingle();
    if (!existing) { res.status(404).json({ error: "Not found" }); return; }
    if ((existing as any).author_id !== user.id) { res.status(403).json({ error: "Forbidden" }); return; }

    const { data, error } = await svc
      .from("comments")
      .update({ content: content.trim() })
      .eq("id", cid)
      .select("*")
      .single();

    if (error) { 
      logger.error({ err: error }, "[posts/comments/:cid] update error");
      res.status(500).json({ error: error.message }); 
      return; 
    }
    const [withAuthor] = await attachCommentAuthors([data as any]);
    res.json({ comment: withAuthor ?? data });
  } catch (err) {
    logger.error({ err }, "[posts/comments/:cid] error");
    res.status(500).json({ error: "Internal error" });
  }
});

/* ── DELETE /api/posts/:id/comments/:cid — Author or owner ─────────────── */
router.delete("/posts/:id/comments/:cid", requireAuth as any, async (req, res) => {
  try {
    const user = getAuthedUser(req as any);
    const svc  = db();
    const { cid } = req.params;

    const { data: comment } = await svc.from("comments").select("author_id").eq("id", cid).maybeSingle();
    if (!comment) { res.status(404).json({ error: "Not found" }); return; }

    const canDelete = (comment as any).author_id === user.id ||
      (user.email ?? "").toLowerCase() === OWNER_EMAIL;
    if (!canDelete) { res.status(403).json({ error: "Forbidden" }); return; }

    await svc.from("comments").delete().eq("id", cid);
    res.json({ ok: true });
  } catch (err) {
    logger.error({ err }, "[posts/comments] delete error");
    res.status(500).json({ error: "Internal error" });
  }
});

/* ════════════════════════════════════════════════════════════════════════════════
   §5  REPORTS
═════════════════════════════════════════════════════════════════════════════════ */

const VALID_REASONS = ["spam","inappropriate","harassment","misinformation","other"] as const;

/* ── POST /api/posts/:id/report ─────────────────────────────────────────── */
router.post("/posts/:id/report", requireAuth as any, async (req, res) => {
  try {
    const user = getAuthedUser(req as any);
    const svc  = db();
    const { reason = "other", notes } = req.body ?? {};

    if (!VALID_REASONS.includes(reason)) {
      res.status(422).json({ error: `reason must be one of: ${VALID_REASONS.join(", ")}` });
      return;
    }

    const { error } = await svc.from("reports").insert({
      reporter_id: user.id,
      post_id: req.params["id"],
      reason,
      notes: notes?.trim()?.slice(0, 500) ?? null,
    });

    if (error) { 
      logger.error({ err: error }, "[posts/report] insert error");
      res.status(500).json({ error: error.message }); 
      return; 
    }
    res.json({ ok: true });
  } catch (err) {
    logger.error({ err }, "[posts/report] error");
    res.status(500).json({ error: "Internal error" });
  }
});

/* ── POST /api/posts/:id/comments/:cid/report ──────────────────────────── */
router.post("/posts/:id/comments/:cid/report", requireAuth as any, async (req, res) => {
  try {
    const user = getAuthedUser(req as any);
    const svc  = db();
    const { reason = "other", notes } = req.body ?? {};

    if (!VALID_REASONS.includes(reason)) {
      res.status(422).json({ error: `reason must be one of: ${VALID_REASONS.join(", ")}` });
      return;
    }

    const { error } = await svc.from("reports").insert({
      reporter_id: user.id,
      comment_id: req.params["cid"],
      reason,
      notes: notes?.trim()?.slice(0, 500) ?? null,
    });

    if (error) { 
      logger.error({ err: error }, "[posts/comments/report] insert error");
      res.status(500).json({ error: error.message }); 
      return; 
    }
    res.json({ ok: true });
  } catch (err) {
    logger.error({ err }, "[posts/comments/report] error");
    res.status(500).json({ error: "Internal error" });
  }
});

/* ════════════════════════════════════════════════════════════════════════════════
   §6  VIEW COUNTER
   Strategy:
   • Authenticated users → DB-backed (post_views table, migration 45).
     The record_post_view RPC atomically inserts and increments; the
     unique constraint prevents double-counting across restarts/replicas.
   • Anonymous users → in-memory 24 h fingerprint cache (IP + UA).
     No user identity to store, so DB dedup is not possible.
═════════════════════════════════════════════════════════════════════════════════ */

router.post("/posts/:id/view", async (req, res) => {
  try {
    const svc = db();
    const postId = req.params["id"];

    // X-style repeat view behavior: every successful view request counts.
    const { error } = await svc.rpc("increment_post_views", { post_id: postId });
    if (error) {
      logger.warn({ err: error, postId }, "[posts/view] increment RPC unavailable");
      res.json({ ok: true, counted: false });
      return;
    }
    res.json({ ok: true, counted: true });
  } catch {
    res.json({ ok: true, counted: false });
  }
});

/* ════════════════════════════════════════════════════════════════════════════════
   §7  NOTIFICATIONS
═════════════════════════════════════════════════════════════════════════════════ */

/* ── GET /api/notifications ─────────────────────────────────────────────── */
router.get("/notifications", requireAuth as any, async (req, res) => {
  try {
    const user  = getAuthedUser(req as any);
    const svc   = db();
    const limit = Math.min(Number(req.query["limit"] ?? 30), 50);
    const offset = Number(req.query["offset"] ?? 0);

    const { data, error } = await svc
      .from("post_notifications")
      .select(`
        id, type, read, created_at, post_id, comment_id,
        actor:users!post_notifications_actor_id_fkey(id, name, username, avatar_url)
      `)
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .range(offset, offset + limit - 1);

    if (error) {
      if ((error.message ?? "").includes("does not exist")) {
        res.json({ notifications: [], unread: 0 });
        return;
      }
      logger.error({ err: error }, "[notifications] select error");
      res.status(500).json({ error: error.message });
      return;
    }

    /* Separate COUNT query for total unread — not capped by page size */
    const { count: unreadCount } = await svc
      .from("post_notifications")
      .select("id", { count: "exact", head: true })
      .eq("user_id", user.id)
      .eq("read", false);

    res.json({ notifications: data ?? [], unread: unreadCount ?? 0 });
  } catch (err) {
    logger.error({ err }, "[notifications] error");
    res.status(500).json({ error: "Internal error" });
  }
});

/* ── PUT /api/notifications/read-all ───────────────────────────────────── */
router.put("/notifications/read-all", requireAuth as any, async (req, res) => {
  try {
    const user = getAuthedUser(req as any);
    const svc  = db();
    await svc.from("post_notifications").update({ read: true }).eq("user_id", user.id).eq("read", false);
    res.json({ ok: true });
  } catch (err) {
    logger.error({ err }, "[notifications/read-all] error");
    res.status(500).json({ error: "Internal error" });
  }
});

/* ── PUT /api/notifications/:id/read ───────────────────────────────────── */
router.put("/notifications/:id/read", requireAuth as any, async (req, res) => {
  try {
    const user = getAuthedUser(req as any);
    const svc  = db();
    await svc.from("post_notifications").update({ read: true })
      .eq("id", req.params["id"]).eq("user_id", user.id);
    res.json({ ok: true });
  } catch (err) {
    logger.error({ err }, "[notifications/:id/read] error");
    res.status(500).json({ error: "Internal error" });
  }
});

/* ════════════════════════════════════════════════════════════════════════════════
   §8  OWNER MODERATION
═════════════════════════════════════════════════════════════════════════════════ */

/* ── GET /api/owner/reports — Review queue ──────────────────────────────── */
router.get("/owner/reports", requireAuth as any, async (req, res) => {
  try {
    if (!isOwnerUser(req)) { res.status(403).json({ error: "Owner only" }); return; }
    const svc    = db();
    const status = req.query["status"] as string ?? "pending";
    const limit  = Math.min(Number(req.query["limit"] ?? 50), 100);

    const { data, error } = await svc
      .from("reports")
      .select("*")
      .eq("status", status)
      .order("created_at", { ascending: false })
      .limit(limit);

    if (error) { 
      logger.error({ err: error }, "[owner/reports] select error");
      res.status(500).json({ error: error.message }); 
      return; 
    }
    const reports = await (async () => {
      const ids = [...new Set((data ?? []).map((r: any) => r.reporter_id).filter(Boolean))];
      if (!ids.length) return data ?? [];
      const { data: users } = await svc.from("users").select("id, name, username, avatar_url").in("id", ids);
      const map: Record<string, any> = {};
      for (const u of (users as any[]) ?? []) map[u.id] = u;
      return (data ?? []).map((r: any) => ({ ...r, reporter: map[r.reporter_id] ?? null }));
    })();
    res.json({ reports });
  } catch (err) {
    logger.error({ err }, "[owner/reports] error");
    res.status(500).json({ error: "Internal error" });
  }
});

/* ── PUT /api/owner/reports/:id — Update report status ──────────────────── */
router.put("/owner/reports/:id", requireAuth as any, async (req, res) => {
  try {
    if (!isOwnerUser(req)) { res.status(403).json({ error: "Owner only" }); return; }
    const svc  = db();
    const user = getAuthedUser(req as any);
    const { status } = req.body ?? {};

    if (!["reviewed","dismissed","actioned"].includes(status)) {
      res.status(422).json({ error: "Invalid status" }); return;
    }

    await svc.from("reports").update({
      status,
      reviewed_by: user.id,
      reviewed_at: new Date().toISOString(),
    }).eq("id", req.params["id"]);

    res.json({ ok: true });
  } catch (err) {
    logger.error({ err }, "[owner/reports/:id] error");
    res.status(500).json({ error: "Internal error" });
  }
});

export default router;
